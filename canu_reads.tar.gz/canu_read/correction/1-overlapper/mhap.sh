#!/bin/sh

jobid=$1
if [ x$jobid = x -o x$jobid = xundefined -o x$jobid = x0 ]; then
  jobid=$1
fi
if [ x$jobid = x ]; then
  echo Error: I need 1 set, or a job index on the command line.
  exit 1
fi

if [ $jobid -eq 1 ] ; then
  blk="000001"
  slf=""
  cvt="-h 1 0 -q 1"
  qry="000001"
fi


if [ x$qry = x ]; then
  echo Error: Job index out of range.
  exit 1
fi

if [ -e /auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/results/$qry.ovb.gz ]; then
  echo Job previously completed successfully.
  exit
fi

if [ ! -d /auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/results ]; then
  mkdir /auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/results
fi

echo Running block $blk in query $qry

syst=`uname -s`
arch=`uname -m`
name=`uname -n`

if [ "$arch" = "x86_64" ] ; then
  arch="amd64"
fi
if [ "$arch" = "Power Macintosh" ] ; then
  arch="ppc"
fi

bin="/usr/local/canu-1.3/$syst-$arch/bin"

if [ ! -d "$bin" ] ; then
  bin="/usr/local/canu-1.3"
fi


if [ ! -e "/auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/results/$qry.mhap" ] ; then
  /usr/lib/jvm/java-8-oracle/bin/java -d64 -server -Xmx6g \
    -jar $bin/mhap-2.1.jar \
    --repeat-weight 0.9 -k 16 \
    --num-hashes 768 \
    --num-min-matches 2 \
    --threshold 0.73 \
    --filter-threshold 0.000005 \
    --ordered-sketch-size 1536 \
    --ordered-kmer-size 12 \
    --num-threads 4 \
    -f /auto/dtchome/thorpec/Hackathon/canu_read/correction/0-mercounts/canu_read.ms16.frequentMers.ignore.gz\
    -s /auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/blocks/$blk.dat $slf\
    -q /auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/queries/$qry\
  > /auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/results/$qry.mhap.WORKING \
  && \
  mv -f /auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/results/$qry.mhap.WORKING /auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/results/$qry.mhap
fi

if [   -e "/auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/results/$qry.mhap" -a \
     ! -e "/auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/results/$qry.ovb.gz" ] ; then
  $bin/mhapConvert \
    $cvt \
    -o /auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/results/$qry.mhap.ovb.WORKING.gz \
    /auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/results/$qry.mhap \
  && \
  mv /auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/results/$qry.mhap.ovb.WORKING.gz /auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/results/$qry.mhap.ovb.gz
fi

if [   -e "/auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/results/$qry.mhap" -a \
       -e "/auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/results/$qry.mhap.ovb.gz" ] ; then
  rm -f /auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/results/$qry.mhap
fi

if [ -e "/auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/results/$qry.mhap.ovb.gz" ] ; then
  mv -f "/auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/results/$qry.mhap.ovb.gz" "/auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/results/$qry.ovb.gz"
fi



exit 0
