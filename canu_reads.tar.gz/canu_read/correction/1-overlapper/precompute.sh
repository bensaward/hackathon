#!/bin/sh

jobid=$1
if [ x$jobid = x -o x$jobid = xundefined -o x$jobid = x0 ]; then
  jobid=$1
fi
if [ x$jobid = x ]; then
  echo Error: I need 1 set, or a job index on the command line.
  exit 1
fi

if [ $jobid -eq 1 ] ; then
  rge="-b 1 -e 556"
  job="000001"
fi


if [ x$job = x ] ; then
  echo Job partitioning error.  jobid $jobid is invalid.
  exit 1
fi

if [ ! -d /auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/blocks ]; then
  mkdir /auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/blocks
fi

if [ -e /auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/blocks/$job.dat ]; then
  echo Job previously completed successfully.
  exit
fi

#  If the fasta exists, our job failed, and we should try again.
if [ -e "/auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/blocks/$job.fasta" ] ; then
  rm -f /auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/blocks/$job.dat
fi

syst=`uname -s`
arch=`uname -m`
name=`uname -n`

if [ "$arch" = "x86_64" ] ; then
  arch="amd64"
fi
if [ "$arch" = "Power Macintosh" ] ; then
  arch="ppc"
fi

bin="/usr/local/canu-1.3/$syst-$arch/bin"

if [ ! -d "$bin" ] ; then
  bin="/usr/local/canu-1.3"
fi


$bin/gatekeeperDumpFASTQ \
  -G /auto/dtchome/thorpec/Hackathon/canu_read/correction/canu_read.gkpStore \
  $rge \
  -nolibname \
  -fasta \
  -o /auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/blocks/$job \
|| \
mv -f /auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/blocks/$job.fasta /auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/blocks/$job.fasta.FAILED


if [ ! -e "/auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/blocks/$job.fasta" ] ; then
  echo Failed to extract fasta.
  exit 1
fi

echo Starting mhap precompute.

#  So mhap writes its output in the correct spot.
cd /auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/blocks

/usr/lib/jvm/java-8-oracle/bin/java -d64 -server -Xmx6g \
  -jar $bin/mhap-2.1.jar \
  --repeat-weight 0.9 -k 16 \
  --num-hashes 768 \
  --num-min-matches 2 \
  --ordered-sketch-size 1536 \
  --ordered-kmer-size 12 \
  --threshold 0.73 \
  --filter-threshold 0.000005 \
  --num-threads 4 \
  -f /auto/dtchome/thorpec/Hackathon/canu_read/correction/0-mercounts/canu_read.ms16.frequentMers.ignore.gz\
  -p /auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/blocks/$job.fasta\
  -q /auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/blocks\
|| \
mv -f /auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/blocks/$job.dat /auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/blocks/$job.dat.FAILED

if [ ! -e "/auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/blocks/$job.dat" ] ; then
  echo Mhap failed.
  exit 1
fi

#  Clean up, remove the fasta input
rm -f /auto/dtchome/thorpec/Hackathon/canu_read/correction/1-overlapper/blocks/$job.fasta

exit 0
