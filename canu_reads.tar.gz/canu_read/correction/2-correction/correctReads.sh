#!/bin/sh

jobid=$1
if [ x$jobid = x -o x$jobid = xundefined -o x$jobid = x0 ]; then
  jobid=$1
fi
if [ x$jobid = x ]; then
  echo Error: I need 1 set, or a job index on the command line.
  exit 1
fi

if [ $jobid -gt 1 ]; then
  echo Error: Only 1 partitions, you asked for $jobid.
  exit 1
fi

if [ $jobid -eq 1 ] ; then
  bgn=1
  end=556
fi

jobid=`printf %04d $jobid`

if [ -e "/auto/dtchome/thorpec/Hackathon/canu_read/correction/2-correction/correction_outputs/$jobid.fasta" ] ; then
  echo Job finished successfully.
  exit 0
fi

if [ ! -d "/auto/dtchome/thorpec/Hackathon/canu_read/correction/2-correction/correction_outputs" ] ; then
  mkdir -p "/auto/dtchome/thorpec/Hackathon/canu_read/correction/2-correction/correction_outputs"
fi

syst=`uname -s`
arch=`uname -m`
name=`uname -n`

if [ "$arch" = "x86_64" ] ; then
  arch="amd64"
fi
if [ "$arch" = "Power Macintosh" ] ; then
  arch="ppc"
fi

bin="/usr/local/canu-1.3/$syst-$arch/bin"

if [ ! -d "$bin" ] ; then
  bin="/usr/local/canu-1.3"
fi



if [ "x$BASH" != "x" ] ; then
  set -o pipefail
fi

( \
$bin/generateCorrectionLayouts -b $bgn -e $end \
  -rl /auto/dtchome/thorpec/Hackathon/canu_read/correction/2-correction/canu_read.readsToCorrect \
  -G /auto/dtchome/thorpec/Hackathon/canu_read/correction/canu_read.gkpStore \
  -O /auto/dtchome/thorpec/Hackathon/canu_read/correction/canu_read.ovlStore \
  -S /auto/dtchome/thorpec/Hackathon/canu_read/correction/2-correction/canu_read.globalScores \
  -C 80 \
  -F \
&& \
  touch /auto/dtchome/thorpec/Hackathon/canu_read/correction/2-correction/correction_outputs/$jobid.dump.success \
) \
| \
$bin/falcon_sense \
  --min_idt 0.5 \
  --min_len 1000\
  --max_read_len 95998\
  --min_ovl_len 500\
  --min_cov 0 \
  --n_core 2 \
  > /auto/dtchome/thorpec/Hackathon/canu_read/correction/2-correction/correction_outputs/$jobid.fasta.WORKING \
 2> /auto/dtchome/thorpec/Hackathon/canu_read/correction/2-correction/correction_outputs/$jobid.err \
&& \
mv /auto/dtchome/thorpec/Hackathon/canu_read/correction/2-correction/correction_outputs/$jobid.fasta.WORKING /auto/dtchome/thorpec/Hackathon/canu_read/correction/2-correction/correction_outputs/$jobid.fasta \

if [ ! -e "/auto/dtchome/thorpec/Hackathon/canu_read/correction/2-correction/correction_outputs/$jobid.dump.success" ] ; then
  echo Read layout generation failed.
  mv /auto/dtchome/thorpec/Hackathon/canu_read/correction/2-correction/correction_outputs/$jobid.fasta /auto/dtchome/thorpec/Hackathon/canu_read/correction/2-correction/correction_outputs/$jobid.fasta.INCOMPLETE
fi

exit 0
