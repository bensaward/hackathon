#!/bin/sh

if [ -e /auto/dtchome/thorpec/Hackathon/canu_read/trimming/canu_read.tigStore/seqDB.v001.tig ] ; then
  exit 0
fi

syst=`uname -s`
arch=`uname -m`
name=`uname -n`

if [ "$arch" = "x86_64" ] ; then
  arch="amd64"
fi
if [ "$arch" = "Power Macintosh" ] ; then
  arch="ppc"
fi

bin="/usr/local/canu-1.3/$syst-$arch/bin"

if [ ! -d "$bin" ] ; then
  bin="/usr/local/canu-1.3"
fi


#  Purge any previous intermediate result.  Possibly not needed, but safer.

rm -f /auto/dtchome/thorpec/Hackathon/canu_read/trimming/0-mercounts/canu_read.ms22.WORKING*

$bin/meryl \
  -B -C -L 2 -v -m 22 -threads 4 -memory 6553 \
  -s /auto/dtchome/thorpec/Hackathon/canu_read/trimming/canu_read.gkpStore \
  -o /auto/dtchome/thorpec/Hackathon/canu_read/trimming/0-mercounts/canu_read.ms22.WORKING \
&& \
mv /auto/dtchome/thorpec/Hackathon/canu_read/trimming/0-mercounts/canu_read.ms22.WORKING.mcdat /auto/dtchome/thorpec/Hackathon/canu_read/trimming/0-mercounts/canu_read.ms22.FINISHED.mcdat \
&& \
mv /auto/dtchome/thorpec/Hackathon/canu_read/trimming/0-mercounts/canu_read.ms22.WORKING.mcidx /auto/dtchome/thorpec/Hackathon/canu_read/trimming/0-mercounts/canu_read.ms22.FINISHED.mcidx

exit 0
