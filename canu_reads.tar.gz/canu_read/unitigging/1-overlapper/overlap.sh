#!/bin/sh

perl='/usr/bin/env perl'

jobid=$1
if [ x$jobid = x -o x$jobid = xundefined -o x$jobid = x0 ]; then
  jobid=$1
fi
if [ x$jobid = x ]; then
  echo Error: I need 1 set, or a job index on the command line.
  exit 1
fi

if [ $jobid -eq 1 ] ; then
  bat="001"
  job="001/000001"
  opt="-h 1-165 -r 1-165 --hashstrings 165 --hashdatalen 696452"
fi


if [ ! -d /auto/dtchome/thorpec/Hackathon/canu_read/unitigging/1-overlapper/$bat ]; then
  mkdir /auto/dtchome/thorpec/Hackathon/canu_read/unitigging/1-overlapper/$bat
fi

if [ -e /auto/dtchome/thorpec/Hackathon/canu_read/unitigging/1-overlapper/$job.ovb.gz ]; then
  echo Job previously completed successfully.
  exit
fi

syst=`uname -s`
arch=`uname -m`
name=`uname -n`

if [ "$arch" = "x86_64" ] ; then
  arch="amd64"
fi
if [ "$arch" = "Power Macintosh" ] ; then
  arch="ppc"
fi

bin="/usr/local/canu-1.3/$syst-$arch/bin"

if [ ! -d "$bin" ] ; then
  bin="/usr/local/canu-1.3"
fi


$bin/overlapInCore \
  -t 4 \
  -k 22 \
  -k /auto/dtchome/thorpec/Hackathon/canu_read/unitigging/0-mercounts/canu_read.ms22.frequentMers.fasta \
  --hashbits 23 \
  --hashload 0.75 \
  --maxerate  0.144 \
  --minlength 500 \
  $opt \
  -o /auto/dtchome/thorpec/Hackathon/canu_read/unitigging/1-overlapper/$job.ovb.WORKING.gz \
  -s /auto/dtchome/thorpec/Hackathon/canu_read/unitigging/1-overlapper/$job.stats \
  /auto/dtchome/thorpec/Hackathon/canu_read/unitigging/canu_read.gkpStore \
&& \
mv /auto/dtchome/thorpec/Hackathon/canu_read/unitigging/1-overlapper/$job.ovb.WORKING.gz /auto/dtchome/thorpec/Hackathon/canu_read/unitigging/1-overlapper/$job.ovb.gz

exit 0
