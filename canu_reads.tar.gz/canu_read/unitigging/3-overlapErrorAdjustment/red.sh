#!/bin/sh


jobid=$1
if [ x$jobid = x -o x$jobid = xundefined -o x$jobid = x0 ]; then
  jobid=$1
fi
if [ x$jobid = x ]; then
  echo Error: I need 1 set, or a job index on the command line.
  exit 1
fi

if [ $jobid = 1 ] ; then
  minid=1
  maxid=164
fi
jobid=`printf %04d $jobid`

if [ -e /auto/dtchome/thorpec/Hackathon/canu_read/unitigging/3-overlapErrorAdjustment/$jobid.red ] ; then
  echo Job previously completed successfully.
  exit
fi
syst=`uname -s`
arch=`uname -m`
name=`uname -n`

if [ "$arch" = "x86_64" ] ; then
  arch="amd64"
fi
if [ "$arch" = "Power Macintosh" ] ; then
  arch="ppc"
fi

bin="/usr/local/canu-1.3/$syst-$arch/bin"

if [ ! -d "$bin" ] ; then
  bin="/usr/local/canu-1.3"
fi

if [ ! -e /auto/dtchome/thorpec/Hackathon/canu_read/unitigging/3-overlapErrorAdjustment/$jobid.red ] ; then
  $bin/findErrors \
    -G /auto/dtchome/thorpec/Hackathon/canu_read/unitigging/canu_read.gkpStore \
    -O /auto/dtchome/thorpec/Hackathon/canu_read/unitigging/canu_read.ovlStore \
    -R $minid $maxid \
    -e 0.144 -l 500 \
    -o /auto/dtchome/thorpec/Hackathon/canu_read/unitigging/3-overlapErrorAdjustment/$jobid.red.WORKING \
    -t 4 \
  && \
  mv /auto/dtchome/thorpec/Hackathon/canu_read/unitigging/3-overlapErrorAdjustment/$jobid.red.WORKING /auto/dtchome/thorpec/Hackathon/canu_read/unitigging/3-overlapErrorAdjustment/$jobid.red
fi
