#!/bin/sh

if [ -e /auto/dtchome/thorpec/Hackathon/canu_read/unitigging/canu_read.tigStore/seqDB.v001.tig ] ; then
  exit 0
fi

syst=`uname -s`
arch=`uname -m`
name=`uname -n`

if [ "$arch" = "x86_64" ] ; then
  arch="amd64"
fi
if [ "$arch" = "Power Macintosh" ] ; then
  arch="ppc"
fi

bin="/usr/local/canu-1.3/$syst-$arch/bin"

if [ ! -d "$bin" ] ; then
  bin="/usr/local/canu-1.3"
fi


$bin/bogart \
 -G /auto/dtchome/thorpec/Hackathon/canu_read/unitigging/canu_read.gkpStore \
 -O /auto/dtchome/thorpec/Hackathon/canu_read/unitigging/canu_read.ovlStore \
 -T /auto/dtchome/thorpec/Hackathon/canu_read/unitigging/canu_read.tigStore.WORKING \
 -o /auto/dtchome/thorpec/Hackathon/canu_read/unitigging/4-unitigger/canu_read \
 -B 20 \
 -gs 1257000 \
 -eg 0.144 \
 -eM 0.144 \
 -el 500 \
 -dg 6 \
 -db 6 \
 -dr 3 \
 -ca 5000 \
 -cp 500 \
 -threads 4 \
 -M 8 \
 -unassembled 2 1000 0.75 0.75 2 \
 > /auto/dtchome/thorpec/Hackathon/canu_read/unitigging/4-unitigger/unitigger.err 2>&1 \
&& \
mv /auto/dtchome/thorpec/Hackathon/canu_read/unitigging/canu_read.tigStore.WORKING /auto/dtchome/thorpec/Hackathon/canu_read/unitigging/canu_read.tigStore.FINISHED

exit 0
