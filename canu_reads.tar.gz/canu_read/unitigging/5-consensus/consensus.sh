#!/bin/sh

jobid=$1
if [ x$jobid = x -o x$jobid = xundefined -o x$jobid = x0 ]; then
  jobid=$1
fi
if [ x$jobid = x ]; then
  echo Error: I need 1 set, or a job index on the command line.
  exit 1
fi

if [ $jobid -gt 9 ]; then
  echo Error: Only 9 partitions, you asked for $jobid.
  exit 1
fi

jobid=`printf %04d $jobid`

if [ -e /auto/dtchome/thorpec/Hackathon/canu_read/unitigging/5-consensus/$jobid.cns ] ; then
  exit 0
fi

syst=`uname -s`
arch=`uname -m`
name=`uname -n`

if [ "$arch" = "x86_64" ] ; then
  arch="amd64"
fi
if [ "$arch" = "Power Macintosh" ] ; then
  arch="ppc"
fi

bin="/usr/local/canu-1.3/$syst-$arch/bin"

if [ ! -d "$bin" ] ; then
  bin="/usr/local/canu-1.3"
fi


$bin/utgcns \
  -G /auto/dtchome/thorpec/Hackathon/canu_read/unitigging/canu_read.gkpStore \
  -T /auto/dtchome/thorpec/Hackathon/canu_read/unitigging/canu_read.tigStore 1 $jobid \
  -O /auto/dtchome/thorpec/Hackathon/canu_read/unitigging/5-consensus/$jobid.cns.WORKING \
  -maxcoverage 40 \
  -e 0.144 \
  -pbdagcon \
  -threads 4 \
&& \
mv /auto/dtchome/thorpec/Hackathon/canu_read/unitigging/5-consensus/$jobid.cns.WORKING /auto/dtchome/thorpec/Hackathon/canu_read/unitigging/5-consensus/$jobid.cns \

exit 0
